数据格式：
Irradiance：R16G16B16A16_UNORM   80x32x1
Distance：R32G32_FLOAT 160x64x1
Relocation：R16G16B16A16_FLOAT 10x4x1
Classification：R32_FLOAT 10x4x1
probe密度：4x5x2
