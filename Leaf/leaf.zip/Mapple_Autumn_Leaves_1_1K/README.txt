This pack is a lower resolution samples without transparent backgrounds. 
You can use it but you'd need to transform diffuse map to transparency map on your own.
All files are jpegs with some compression. 
Paid pack is 4096x4096px and all files are .png losless compression and have transparent backgrounds.

You can get full product from https://hdrmaps.com
Contact me at contact@hdrmaps.com